const greetingButton = document.querySelectorr("#greeting-button");
greetingButton.addEventListener("click", () => {
  alert("Selamat belajar Pengembangan Situs Web I!");
});
console.log('main.js berhasil dijalankan');